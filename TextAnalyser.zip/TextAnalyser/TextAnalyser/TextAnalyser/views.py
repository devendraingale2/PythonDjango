from django.http import HttpResponse
from django.shortcuts import render


def analyser(request):
    return render(request,'analyser.html')


def analysed(request):
    djtext=request.POST.get('text','default')
    removepunc=request.POST.get('removepunc','off')
    removenewline=request.POST.get('removenewline','off')
    removeexspace=request.POST.get('removeexspace','off')
    uppercase=request.POST.get('uppercase','off')
    charcount=request.POST.get('charcount','off')


    if removepunc=="on":
        punc= ''' ~!@#$%^&*()_+}{P|:"?></.,';\ ][=- '''
        antext=""
        for i in range(len(djtext)):
            if djtext[i] not in punc:
                antext=antext+djtext[i]
            else:
                antext=antext+""

        para={'at':antext}
        djtext=antext


    if removenewline=="on":
        antext=""
        for i in djtext:
            if i != "\n" and i != "\r":
                antext=antext+i
            else:
                antext=antext+""

        para={'at':antext}
        djtext=antext

    if removeexspace=="on":
        antext=""
        for index,char in enumerate(djtext):
            if djtext[index]==" " and djtext[index+1]==" ":
                pass
            else:
                antext=antext+char

        para={'at':antext}
        djtext=antext

    if uppercase == "on":
        antext = ""
        for i in djtext:
            antext = antext + i.upper()

        para = {'at': antext}
        djtext=antext



    if charcount == "on":
        antext = 0

        for i in djtext:
            if i!=" ":
                antext=antext+1

        para = {'at': antext}
        djtext=antext
    if(removepunc!='on' and removenewline!='on' and charcount!='on' and uppercase!='on' and removeexspace!='on'):
        return HttpResponse('Error:Please Select any process..!!')
    return render(request, 'analysed.html', para)